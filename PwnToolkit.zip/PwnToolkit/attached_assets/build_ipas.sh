
#!/bin/bash
set -e

echo "Starting iOS build process..."

# Ensure xcodebuild is available
if ! command -v xcodebuild &> /dev/null; then
    echo "xcodebuild not found, installing build tools..."
    xcode-select --install || true
fi

# Build the project
echo "Building project..."
cd attached_assets/Fugu16
xcodebuild -scheme Fugu16 -configuration Release build
cd ../..

echo "Creating IPA..."
xcrun -sdk iphoneos PackageApplication \
    -v "build/Release-iphoneos/Fugu16.app" \
    -o "build/Fugu16.ipa"

echo "Build complete! IPA file created at build/Fugu16.ipa"
