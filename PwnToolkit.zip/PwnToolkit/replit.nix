{pkgs}: {
  deps = [
    pkgs.llvm
  ];
}
